// mouse.c
// 
// Demonstrates simple mouse interaction
// Program by Bryson R. Payne, M.Ed.
// Georgia State University
// Submitted in Partial Fulfillment of 
// CSc 6820 - Computer Graphics Algorithms 
// Under the Instruction of Dr. G. Scott Owen

// Header files to include
#include <gl/glut.h>	// GLUT toolkit
#include <stdio.h>		// I/O for keyboard interaction
#include <stdlib.h>		// Exit function is in standard library

// Define initial camera position and viewing window values
#define INIT_VIEW_X	 0.0 
#define INIT_VIEW_Y  0.0
#define INIT_VIEW_Z -4.5
#define VIEW_LEFT	-2.0
#define VIEW_RIGHT	 2.0
#define VIEW_BOTTOM	-2.0
#define VIEW_TOP	 2.0
#define VIEW_NEAR	 1.0
#define VIEW_FAR	 200.0

// Two new globals for our mouse interaction
int xAbs,	// placekeeper for x mouse movement 
	yAbs;	// placekeeper for y mouse movement

// Set up the Global Data Structure
// This will contain all the needed information on the 
// object to be drawn at any time. It changes with keyboard input.
struct ImageData {
	GLboolean WireOrFilled;	// 0=Wireframe mode, 1=Filled Polygons
	GLfloat xRot;			// x-rotation amount
	GLfloat yRot;			// y-rotation amount (extra)
	GLfloat zRot;			// z-rotation amount
} 
MyImage;	// MyImage will be of type ImageData - our global friend

// My initialization values for lighting
GLfloat AmbientLight[] =	{ 0.3f, 0.3f, 0.3f, 1.0f };
GLfloat DiffuseLight[] =	{ 0.8f, 0.8f, 0.8f, 1.0f };
GLfloat SpecularLight[] =	{ 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat SpecRef[] =			{ 0.7f, 0.7f, 0.7f, 1.0f };
GLfloat LightPos[] =		{-50.0f,50.0f,100.0f,1.0f};
GLubyte Shine =	128;	

////////////////////////////////////////////////
//Display the current object using MyImage's data
void DisplayObject(void) 
{
	// Initialize everything
	
	// Clear the window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// Change the draw color to the requested color
	glColor3ub(50, 50, 150);
	
	//Save viewing matrix state
	glPushMatrix();
	
	// Do any needed rotation
	glRotatef(MyImage.xRot, 1.0f, 0.0f, 0.0f);
	glRotatef(MyImage.yRot, 0.0f, 1.0f, 0.0f);
	glRotatef(MyImage.zRot, 0.0f, 0.0f, 1.0f);
	
	//Now, let's actually test our structure and draw our object
	switch(MyImage.WireOrFilled)
	{
	case 0:		// Draw a wireframe representation of our shape
		
		//Draw WireFrame Sphere
		glutWireSphere(1.0f, 30, 30);
		break;
		
	case 1:		// Draw a filled polygon representation of our shape
		
		//Draw Filled Sphere
		glutSolidSphere(1.0f, 30, 30);
		break;
		
	default:	// Default object to draw if not initialized
		glutSolidSphere(1.0f, 30, 30);
		break;
	}
	
	// Restore matrix state
	glPopMatrix();
	
	// Flush drawing commands
	glutSwapBuffers();
	
} // End of DisplayObject

void SetupRend()
{
	// Set background to black
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	
	// Enable depth testing
	glEnable(GL_DEPTH_TEST);
	
	// Enable lighting
	glEnable(GL_LIGHTING);
	
	// Set up and enable light zero
	glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, SpecularLight);
	glEnable(GL_LIGHT0);
	
	// Enable color tracking
	glEnable(GL_COLOR_MATERIAL);
	
	// Set material to folow glColor values
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	
	// Set specular reflectivity and shine
	glMaterialfv(GL_FRONT, GL_SPECULAR, SpecRef);
	glMateriali(GL_FRONT, GL_SHININESS, Shine);
	
}

// Set a perspective window
void ChangeWindow(GLsizei w, GLsizei h)	
{
	GLfloat Ratio;
	
	// Prevent division by zero
	if (h==0)
		h=1;
	
	// Set viewport to window dimensions
	glViewport(0,0,w,h);
	
	// Set the perspective ratios
	Ratio = (GLfloat)w/(GLfloat)h;
	
	// Reset coordinate system
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	
	// Set the viewing perspective
	gluPerspective(50.0f, Ratio, VIEW_NEAR, VIEW_FAR);
	
	// Set viewing translation
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glTranslatef( INIT_VIEW_X, INIT_VIEW_Y, INIT_VIEW_Z );
	glLightfv(GL_LIGHT0, GL_POSITION, LightPos);
	
}

// Process Special Function Keys (arrows for x & z rotation)
void ArrowKeys(int key, int x, int y)
{
	if (key == GLUT_KEY_LEFT)	// rotate in the negative z
		MyImage.zRot -= 5.0f;
	
	if (key == GLUT_KEY_RIGHT)	// rotate in the positive z
		MyImage.zRot += 5.0f;
	
	if (key == GLUT_KEY_UP)		// rotate in the negative x
		MyImage.xRot -= 5.0f;
	
	if (key == GLUT_KEY_DOWN)	// rotate in the postive x
		MyImage.xRot += 5.0f;
	
	if (key == GLUT_KEY_PAGE_UP)	// rotate in the negative y
		MyImage.yRot -= 5.0f;
	
	if (key == GLUT_KEY_PAGE_DOWN)	// rotate in the postive y
		MyImage.yRot += 5.0f;
	
	// Check x,y and z rotation values to keep 0-355
	if (MyImage.xRot > 356.0f)
		MyImage.xRot = 0.0f;
	
	if (MyImage.xRot < 0.0f)
		MyImage.xRot = 355.0f;
	
	if (MyImage.yRot > 356.0f)
		MyImage.yRot = 0.0f;
	
	if (MyImage.yRot < 0.0f)
		MyImage.yRot = 355.0f;
	
	if (MyImage.zRot > 356.0f)
		MyImage.zRot = 0.0f;
	
	if (MyImage.zRot < 0.0f)
		MyImage.zRot = 355.0f;
	
	// Refresh the window
	glutPostRedisplay();
	
}

// Process keyboard input to change object attributes
void KeyPunch (unsigned char key, int x, int y)
{
	
	switch (key)
	{
		
	case 'W':	// Toggle wireframe or filled polygon mode
		MyImage.WireOrFilled = !MyImage.WireOrFilled;
		break;
		
	case 'w':
		MyImage.WireOrFilled = !MyImage.WireOrFilled;
		break;
		
	case 'Q':	// Quit the program completely
		exit(1);
		break;
		
	case 'q':
		exit(1);
		break;
		
	}
	
	glutPostRedisplay();
	
} 

// Mouse Interaction function
void MouseMove (int x, int y)
{
	// the x and y values affect the opposite axis values
	// because each is rotation "about an axis", not in a direction
	MyImage.xRot += (y-yAbs);	// turn left or right 
	yAbs = y;					// refresh our x value
	
	MyImage.yRot += (x-xAbs);	// rotate up or down
	xAbs = x;					// refresh our y value
	
	// Check x,y rotation values to keep 0-355
	if (MyImage.xRot > 360.0f)
		MyImage.xRot -= 360.0f;
	
	if (MyImage.xRot < 0.0f)
		MyImage.xRot += 360.0f;
	
	if (MyImage.yRot > 360.0f)
		MyImage.yRot -= 360.0f;
	
	if (MyImage.yRot < 0.0f)
		MyImage.yRot += 360.0f;
		
	// Refresh the window
	glutPostRedisplay();
}

// Detect mouse button press to start Mouse Interaction
void MousePress(int button, int state, int x, int y) {
	if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN))
	{
		xAbs = x;	// Mouse button has been pushed - 
		yAbs = y;	// set absolute x,z to new x/y coords for movement detection
	}
}

//////////////////////////////////////////////////
// Main program module
void main(void)
{
	// Set a default value for our object to draw
	MyImage.WireOrFilled=1;		// filled
	MyImage.xRot=0.0f;			// normal orientation
	MyImage.yRot=0.0f;
	MyImage.zRot=0.0f;
	
	// Show a Welcome Screen with text instructions
	printf("  * *     Mouse.c - Demonstration of Simple Mouse Interaction    * *  \n");
	printf("                      by Bryson R. Payne, M.Ed.\n\n");			//
	printf("Use the following keys to change the object being drawn in 3D:\n\n");
	printf("   ARROW KEYS & PAGE_UP / PAGE_DOWN - Rotate about X, Y, & Z axes.\n");
	printf("   'W' or 'w' - Toggles wireframe/filled polygon mode.\n");
	printf("   'Q' or 'q' - Quits the program.\n\n");
	printf("   Hold down left mouse button and move mouse to rotate about X & Y axes.\n");

	
	// Set the buffers we want for best viewing
	glutInitDisplayMode ( GLUT_DOUBLE	// double-buffered pixel format for flicker-free movement
		| GLUT_RGB		// use RGB pixel format (easy to color)
		| GLUT_DEPTH);	// use depth buffer (better perspective)
	
	// Create the viewing window
	glutCreateWindow ("Mouse.c - Demonstration of Mouse Interaction");
	
	glutReshapeFunc (ChangeWindow);	// Set function for resizing window
	glutMouseFunc (MousePress);		// Detect mouse button press
	glutMotionFunc (MouseMove);		// Detect mouse movement with button pressed
	glutKeyboardFunc (KeyPunch);	// Set function for key command processing
	glutSpecialFunc (ArrowKeys);	// Set function for special keys (rotation)
	glutDisplayFunc (DisplayObject);	// Set function for redisplaying
	SetupRend();	// Initialize and get ready to draw
	
	glutMainLoop(); // Keep on going until user gets tired
	
}