// objects2.c
// 
// Demonstrates importing 3d meshes with their original material colors
// Program by Bryson R. Payne, M.Ed.
// Georgia State University
// Submitted in Partial Fulfillment of 
// CSc 6820 - Computer Graphics Algorithms 
// Under the Instruction of Dr. G. Scott Owen

#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <GL/glut.h>
#include "glm.c"

#define INIT_VIEW_X	 0.0 
#define INIT_VIEW_Y  0.0
#define INIT_VIEW_Z -4.5
#define VIEW_LEFT	-2.0
#define VIEW_RIGHT	 2.0
#define VIEW_BOTTOM	-2.0
#define VIEW_TOP	 2.0
#define VIEW_NEAR	 1.0
#define VIEW_FAR	 200.0

struct ImageData {
	GLfloat xRot;			// x-rotation amount
	GLfloat yRot;			// y-rotation amount (extra)
	GLfloat zRot;			// z-rotation amount
} 
MyImage;	// MyImage will be of type ImageData - our global friend

GLuint     model_list = 0;		/* display list for object */
GLMmodel*  model;
GLfloat ambient[]	= { 0.2, 0.2, 0.2, 1.0 };
GLfloat diffuse[]	= { 0.8, 0.8, 0.8, 1.0 };
GLfloat specular[]	= { 0.0, 0.0, 0.0, 1.0 };
GLfloat shininess	= 65.0;
GLfloat LightPos[]	= {-50.0f,50.0f,100.0f,1.0f};

int xAbs,	// placekeeper for x mouse movement 
	yAbs;	// placekeeper for y mouse movement

void
display(void)
{
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPushMatrix();
	// Do needed rotation
	glRotatef(MyImage.xRot, 1.0f, 0.0f, 0.0f);
	glRotatef(MyImage.yRot, 0.0f, 1.0f, 0.0f);
	glRotatef(MyImage.zRot, 0.0f, 0.0f, 1.0f);
	
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glColor3f(0.3, 0.3, 0.3);

	// Call the stored display list
	glCallList(model_list);
	glPopMatrix();
	glutSwapBuffers();
	
}

void SetupRend()
{
	// Set background to black
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	// enable lighting
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	// enable depth testing
	glEnable(GL_DEPTH_TEST);
	// enable backface culling
	glEnable(GL_CULL_FACE);
	
}

void ChangeWindow(GLsizei w, GLsizei h)	
{
	GLfloat Ratio;
	
	// Prevent division by zero
	if (h==0)
		h=1;
	
	// Set viewport to window dimensions
	glViewport(0,0,w,h);
	
	// Set the perspective ratios
	Ratio = (GLfloat)w/(GLfloat)h;
	
	// Reset coordinate system
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	
	// Set the viewing perspective
	gluPerspective(50.0f, Ratio, VIEW_NEAR, VIEW_FAR);
	
	// Set viewing translation
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glTranslatef( INIT_VIEW_X, INIT_VIEW_Y, INIT_VIEW_Z );
	glLightfv(GL_LIGHT0, GL_POSITION, LightPos);
	
}

// Process Special Function Keys (arrows for x & z rotation)
void ArrowKeys(int key, int x, int y)
{
	if (key == GLUT_KEY_LEFT)	// rotate in the negative z
		MyImage.zRot -= 5.0f;
	
	if (key == GLUT_KEY_RIGHT)	// rotate in the positive z
		MyImage.zRot += 5.0f;
	
	if (key == GLUT_KEY_UP)		// rotate in the negative x
		MyImage.xRot -= 5.0f;
	
	if (key == GLUT_KEY_DOWN)	// rotate in the postive x
		MyImage.xRot += 5.0f;
	
	if (key == GLUT_KEY_PAGE_UP)	// rotate in the negative y
		MyImage.yRot -= 5.0f;
	
	if (key == GLUT_KEY_PAGE_DOWN)	// rotate in the postive y
		MyImage.yRot += 5.0f;
	
	// Check x,y and z rotation values to keep 0-355
	if (MyImage.xRot > 356.0f)
		MyImage.xRot = 0.0f;
	
	if (MyImage.xRot < 0.0f)
		MyImage.xRot = 355.0f;
	
	if (MyImage.yRot > 356.0f)
		MyImage.yRot = 0.0f;
	
	if (MyImage.yRot < 0.0f)
		MyImage.yRot = 355.0f;
	
	if (MyImage.zRot > 356.0f)
		MyImage.zRot = 0.0f;
	
	if (MyImage.zRot < 0.0f)
		MyImage.zRot = 355.0f;
	
	// Refresh the window
	glutPostRedisplay();
	
}

// Process keyboard input to change object attributes
void KeyPunch (unsigned char key, int x, int y)
{
	
	switch (key)
	{
		
	case 'Q':	// Quit the program completely
		exit(1);
		break;
		
	case 'q':
		exit(1);
		break;
		
	}
	
	glutPostRedisplay();
	
} 

// Mouse Interaction function
void MouseMove (int x, int y)
{
	// the x and y values affect the opposite axis values
	// because each is rotation "about an axis", not in a direction
	MyImage.xRot += (y-yAbs);	// turn left or right 
	yAbs = y;					// refresh our x value
	
	MyImage.yRot += (x-xAbs);	// rotate up or down
	xAbs = x;					// refresh our y value
	
	// Check x,y rotation values to keep 0-355
	if (MyImage.xRot > 360.0f)
		MyImage.xRot -= 360.0f;
	
	if (MyImage.xRot < 0.0f)
		MyImage.xRot += 360.0f;
	
	if (MyImage.yRot > 360.0f)
		MyImage.yRot -= 360.0f;
	
	if (MyImage.yRot < 0.0f)
		MyImage.yRot += 360.0f;
	
	// Refresh the window
	glutPostRedisplay();
}

// Detect mouse button press to start Mouse Interaction
void MousePress(int button, int state, int x, int y) {
	if ((button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN))
	{
		xAbs = x;	// Mouse button has been pushed - 
		yAbs = y;	// set absolute x,z to new x/y coords for movement detection
	}
}

void main(void)	
{
	
	// Set a default value for our object to draw
	MyImage.xRot=0.0f;			// normal orientation
	MyImage.yRot=0.0f;
	MyImage.zRot=0.0f;
	
	// Show a Welcome Screen with text instructions
	printf("  * *   Objects2.c - Demonstration of 3D Models with Materials  * *  \n");
	printf("                      by Bryson R. Payne, M.Ed.\n\n");			//
	printf("Use the following keys to change the object being drawn in 3D:\n\n");
	printf("   ARROW KEYS & PAGE_UP / PAGE_DOWN - Rotate about X, Y, & Z axes.\n");
	printf("   'Q' or 'q' - Quits the program.\n\n");
	printf("   Hold down left mouse button and move mouse to rotate about X & Y axes.\n");
	
	
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutCreateWindow ("Objects2.c - Demonstration of 3D Models with Materials");
	
	glutReshapeFunc(ChangeWindow);
	glutKeyboardFunc(KeyPunch);
	glutSpecialFunc(ArrowKeys);
	glutDisplayFunc(display);
	glutMouseFunc(MousePress);
	glutMotionFunc(MouseMove);
	
	// Use glm plus display list to store object with original colors
	/* read in the model */
	model = glmReadOBJ("castle.obj");
	glmUnitize(model);
	glmScale(model,2);
	glmFacetNormals(model);
	glmVertexNormals(model, 90.0);
	
	/* set up material for a new display list */
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
	
	/* generate a list */
	model_list = glmList(model, GLM_SMOOTH | GLM_MATERIAL);

	SetupRend();
	
	glutMainLoop();
}
